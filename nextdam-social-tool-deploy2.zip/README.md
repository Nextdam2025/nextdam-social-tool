
# NextDam Social Media Tool

A white-label, lightweight social media scheduling and publishing tool.

## ✨ Features

- Cross-platform posting (Instagram, TikTok, X)
- Hashtag optimization per platform
- Image/video upload
- Post history & calendar overview
- Scheduling (future posts)
- Fully brandable: name, logo, color, font

---

## 🚀 Deploy on GitHub Pages

1. Clone this repository:
   ```bash
   git clone https://github.com/YOUR_USERNAME/your-client-tool.git
   cd your-client-tool
   ```

2. Commit and push to GitHub

3. Go to **Settings > Pages** and set:
   - Source: `main`
   - Folder: `/ (root)`

4. Your tool is now live on GitHub Pages 🎉

---

## 🎨 White-label Branding

To rebrand for a client, open `app.jsx` and modify:

```js
const BRAND = {
  name: 'Your Client Name',
  logoUrl: 'https://yourdomain.com/logo.png',
  primaryColor: '#007BFF',
  font: 'Roboto, sans-serif',
};
```

---

## 🌐 Backend Proxy Setup

This tool expects an API at:

```
POST https://yourproxy.com/api/post
GET  https://yourproxy.com/api/history
```

Use Vercel, Firebase, or any serverless platform to host your backend.

---

## 🏁 Recommended Flow for Clients

1. Duplicate this GitHub repo
2. Replace the logo, colors, name
3. Point to their own proxy
4. Deploy on GitHub Pages or custom domain
5. Optional: add analytics or upgrade plan
